﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

namespace CWRU.Common.HololensInput {
    [RequireComponent(typeof(HandConnected))]
    public class NetworkedHand : NetworkBehaviour {

        HandConnected obj;

        [SyncVar]
        public Vector3 handPosition;

        [SyncVar]
        public Quaternion handRotation;
        
        //Used for initialization
        void Awake() {
            obj = GetComponent<HandConnected>();
            obj.enabled = isLocalPlayer;
        }

        // Update is called once per frame
        void Update() {
            if (isLocalPlayer)
            {
                handPosition = transform.position;
                handRotation = transform.rotation;
                TransmitInfo(handPosition, handRotation);
            }
            else
            {
                transform.position = Vector3.Lerp(transform.position, handPosition, Time.deltaTime * 5f);
                transform.rotation = Quaternion.Lerp(transform.rotation, handRotation, Time.deltaTime * 5f);
            }
        }

        [ClientCallback]
        void TransmitInfo(Vector3 point, Quaternion rotation)
        {
            CmdSendTransformToServer(point,rotation);
        }

        [Command]
        private void CmdSendTransformToServer(Vector3 point, Quaternion rotation)
        {
            handPosition = point;
            handRotation = rotation;
        }
    }
}
