﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

namespace CWRU.Common.HololensInput
{
    /// <summary>
    /// A class to network together the gaze managers of multiple users.
    /// </summary>
    [RequireComponent(typeof(GazeManager))]
    public class NetworkedGaze : NetworkBehaviour
    {
        GazeManager gaze;
        Transform gazeTarget;

        [SyncVar]
        public Vector3 gazePosition;

        // Use this for initialization
        void Start()
        {
            gaze = GetComponent<GazeManager>();
            //gaze.enabled = isLocalPlayer;
            gazeTarget = gaze.gazeMarker;

            Random.seed = (int)GetComponent<NetworkIdentity>().netId.Value;
            gaze.gazeMarker.GetComponent<Renderer>().material.color = Random.ColorHSV(0, 1, 1, 1, 1, 1);

            if (isLocalPlayer)
            {
                gaze.localPlayer = true;
            }
            else
            {
                gaze.localPlayer = false;
            }
        }

        // Update is called once per frame
        void Update()
        {
            // If it is this player,
            if (isLocalPlayer)
            {
                // Update the gaze position and transmit the change to all users.
                gazePosition = gazeTarget.position;
                TransmitInfo(gazePosition);
            }
            // Otherwise...
            else
            {
                // Simply move the gaze marker to the correct position.
                gazeTarget.position = Vector3.Lerp(gazeTarget.position, gazePosition, Time.deltaTime * 5f);
            }
        }

        [ClientCallback]
        void TransmitInfo(Vector3 point)
        {
            CmdSendTransformToServer(point);
        }

        [Command]
        private void CmdSendTransformToServer(Vector3 point)
        {
            gazePosition = point;
        }
    }
}
