﻿using UnityEngine;
using System.Collections;

public class SheetMusicScript : MonoBehaviour {
    // TODO: change these two variables to private when done with testing!
    public bool isPlaying;
    public bool isReset;

    private float speed;

    private Object[] objects;
    private Texture[] musicImages;
    private int musicImageCount;

    private GameObject[] musicPanels;
    public GameObject musicPanel1;
    private GameObject musicPanel2;

    private bool firstLerp;
    private Vector3 panelStartPoint;
    private Vector3 panelEndPoint;
    private float startTimeMusicPanel1;
    private float startTimeMusicPanel2;
    private float journeyLength;

    private Vector3 panelStartPointFirstLerp;
    private float journeyLengthFirstLerp;

    private float pauseTime;
    private float durationPaused1;
    private float durationPaused2;

    // Use this for initialization
    void Start() {
        pauseTime = 0;
        durationPaused1 = 0;
        durationPaused2 = 0;

        // TODO: uncomment these once you are done testing so they are initialized to these variables
        //isPlaying = false;
        //isReset = false;
        speed = 1f;
        firstLerp = true;
        panelStartPoint = new Vector3(10, 0, 10);
        panelEndPoint = new Vector3(-10, 0, 10);
        startTimeMusicPanel1 = Time.time;
        startTimeMusicPanel2 = Time.time;
        journeyLength = Vector3.Distance(panelStartPoint, panelEndPoint);

        panelStartPointFirstLerp = new Vector3(20, 0, 10);
        journeyLengthFirstLerp = Vector3.Distance(panelStartPointFirstLerp, panelEndPoint);

        initializeMusicPanels();

        initializeMusicImages();
    }

    // Update is called once per frame
    void Update() {
        // check to make sure reset hasn't been triggered
        if (isPlaying && !isReset) {
            // move musicPanel1
            float distanceCovered1 = (Time.time - durationPaused1 - startTimeMusicPanel1) * speed;
            float fracJourney1 = distanceCovered1 / journeyLength;
            //Debug.Log("fracJourney1: " + fracJourney1);
            musicPanel1.transform.localPosition = Vector3.Lerp(panelStartPoint, panelEndPoint, fracJourney1);

            // check is musicPanel1 needs reset
            if (fracJourney1 >= 1) {
                resetPanel(musicPanel1, 1);
            }

            // if you are lerp-ing for the first time, the 2nd music panel moves further the first time
            // need to account for this by having different start and end points in the Lerp() fxn the first time
            float fracJourneyFirstLerp = -1;
            float fracJourney2 = -1;
            if (firstLerp) {
                float distanceCoveredFirstLerp = (Time.time - durationPaused2 - startTimeMusicPanel2) * speed;
                fracJourneyFirstLerp = distanceCoveredFirstLerp / journeyLengthFirstLerp;
                //Debug.Log("fracJourneyFirstLerp: " + fracJourneyFirstLerp);
                musicPanel2.transform.localPosition = Vector3.Lerp(panelStartPointFirstLerp, panelEndPoint, fracJourneyFirstLerp);
            } else {
                float distanceCovered2 = (Time.time - durationPaused2 - startTimeMusicPanel2) * speed;
                fracJourney2 = distanceCovered2 / journeyLength;
                //Debug.Log("fracJourney2: " + fracJourney2);
                musicPanel2.transform.localPosition = Vector3.Lerp(panelStartPoint, panelEndPoint, fracJourney2);
            }

            // check if musicPanel2 needs reset
            if (fracJourneyFirstLerp >= 1) {
                firstLerp = false;
                resetPanel(musicPanel2, 2);
            }

            if (fracJourney2 >= 1) {
                resetPanel(musicPanel2, 2);
            }

			//GameObject.FindObjectOfType<SheetMusicFade>().texture = getLeftMostPanel().GetComponent<Renderer>().material.mainTexture as Texture2D;
			//Debug.Log ("Changing Texture");
        }
    }

    // use this function to play the sheet music after pausing it
    public void playSheetMusic() {
        durationPaused1 += (Time.time - pauseTime);
        durationPaused2 += (Time.time - pauseTime);
        pauseTime = 0;
        isPlaying = true;
    }

    // use this function to pause the sheet music
    public void pauseSheetMusic() {
        pauseTime = Time.time;
        isPlaying = false;
    }

	public GameObject getLeftMostPanel() {
		if (musicPanel1.transform.position.x < musicPanel2.transform.position.x) {
			return musicPanel1;
		} else {
			return musicPanel2;
		}
	}

    // use this function to reset the sheet music to the beginning
    // this function will also pause the music, so it will be necessary to use the playSheetMusic() function after this
    public void resetSheetMusic() {
        isReset = true;

        durationPaused1 = 0;
        durationPaused2 = 0;

        // reset starting position of the panels
        musicPanel1.transform.localPosition = panelStartPoint;
        musicPanel2.transform.localPosition = new Vector3(20, 0, 10);

        // need to re-initialize these variables
        //speed = 1f;
        firstLerp = true;
        //startTimeMusicPanel1 = Time.time;
        //startTimeMusicPanel2 = Time.time;

        // put the first two sheet music images on to the panels again
        musicPanel1.GetComponent<Renderer>().material.mainTexture = musicImages[0];
        musicPanel2.GetComponent<Renderer>().material.mainTexture = musicImages[1];
        musicImageCount = 2;

        isPlaying = false;
        isReset = false;
    }

    private void resetPanel(GameObject panel, int panelNum) {
        //Debug.Log("Reseting panel #" + panelNum);
        panel.transform.localPosition = panelStartPoint;

        // reset the start time for whichever panel is being reset
        if (panelNum == 1) {
            startTimeMusicPanel1 = Time.time;
            durationPaused1 = 0;
        } else if (panelNum == 2) {
            startTimeMusicPanel2 = Time.time;
            durationPaused2 = 0;
        } else {
            //Debug.Log("You entered in a panel number that was not a 1 or 2");
        }

        // check to make sure there are more images to place on the panel
        if (musicImageCount < musicImages.Length) {
            // apply musicImages[musicImageCount] to panel
            panel.GetComponent<Renderer>().material.mainTexture = musicImages[musicImageCount];

			//Get opposite panel
			if (panel == musicPanel1) {
				//Debug.Log ("True");
				//GameObject.FindObjectOfType<SheetMusicFade> ().texture = musicPanel2.GetComponent<Renderer> ().material.mainTexture as Texture2D;
				//Debug.Log (GameObject.FindObjectOfType<SheetMusicFade> ().texture);
			} else {
				Debug.Log ("False");
				//GameObject.FindObjectOfType<SheetMusicFade> ().texture = musicPanel1.GetComponent<Renderer> ().material.mainTexture as Texture2D;
			}

			SheetMusicFade[] smf = GameObject.FindObjectsOfType<SheetMusicFade> ();

			smf [0].getTextureManually = true;
			smf [1].getTextureManually = true;
			/*if (smf [0].runThisScript) {
				smf [0].runThisScript = false;
				smf [1].runThisScript = true;
				Debug.Log("Here1");
			} else {
				smf [0].runThisScript = true;
				smf [1].runThisScript = false;
				Debug.Log("Here2");
			}*/

			//GameObject.FindObjectOfType<SheetMusicFade>().texture = musicImages[musicImageCount] as Texture2D;

            musicImageCount++;
        } else {
            //we have reached the end of our music, so stop playing
            isPlaying = false;
        }

    }

    private void initializeMusicPanels() {
        // initialize the variables used to reference the music panels
        musicPanels = new GameObject[2];
        musicPanels = GameObject.FindGameObjectsWithTag("MusicPanel");
        if (musicPanels.Length == 0) {
            //Debug.Log("Could not find music panel tags.");
        }
        musicPanel1 = musicPanels[1];
        musicPanel2 = musicPanels[0];
    }

    private void initializeMusicImages() {
        // load images into musicImages[]
        objects = Resources.LoadAll("Images", typeof(Texture));
        if (objects != null) {
            musicImages = new Texture[objects.Length];
            for (int i = 0; i < objects.Length; i++) {
                musicImages[i] = (Texture)objects[i];
            }
            //Debug.Log("musicImages.Length: " + musicImages.Length);
        }

        // check to make sure there is more than one image in the array
        if (musicImages.Length < 1) {
            //Debug.Log("Not enough sheet music images.");
            Debug.Break();
        }

        // put the first two images onto the panels
        musicPanel1.GetComponent<Renderer>().material.mainTexture = musicImages[0];
		GameObject.FindObjectsOfType<SheetMusicFade>()[0].texture = musicImages[0] as Texture2D;
        musicPanel2.GetComponent<Renderer>().material.mainTexture = musicImages[1];
		GameObject.FindObjectsOfType<SheetMusicFade>()[1].texture = musicImages[0] as Texture2D;

		GameObject.FindObjectsOfType<SheetMusicFade> () [0].getTextureManually = true;
		GameObject.FindObjectsOfType<SheetMusicFade> () [1].getTextureManually = true;

        musicImageCount = 2; // is 2 because we have placed the first two images onto the panels already
    }
}
